<?php


//$link = mysqli_connect("localhost", "root", "", "repair");
$link = mysqli_connect("localhost", "webihdme_phixhut", "webihdme_phixhut", "webihdme_phixhut");

?>